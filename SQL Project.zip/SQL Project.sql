create database Employee_Management_System;
use Employee_Management_System;

-- Job Department
CREATE TABLE JobDepartment (
    Job_ID INT PRIMARY KEY,
    jobdept VARCHAR(50),
    name VARCHAR(100),
    description TEXT,
    salaryrange VARCHAR(50)
);

-- Salary/Bonus
CREATE TABLE SalaryBonus (
    salary_ID INT PRIMARY KEY,
    Job_ID INT,
    amount DECIMAL(10,2),
    annual DECIMAL(10,2),
    bonus DECIMAL(10,2),
    CONSTRAINT fk_salary_job FOREIGN KEY (job_ID) REFERENCES JobDepartment(Job_ID)
        ON DELETE CASCADE ON UPDATE CASCADE
);

-- Employee
CREATE TABLE Employee (
    emp_ID INT PRIMARY KEY,
    firstname VARCHAR(50),
    lastname VARCHAR(50),
    gender VARCHAR(10),
    age INT,
    contact_add VARCHAR(100),
    emp_email VARCHAR(100) UNIQUE,
    emp_pass VARCHAR(50),
    Job_ID INT,
    CONSTRAINT fk_employee_job FOREIGN KEY (Job_ID)
        REFERENCES JobDepartment(Job_ID)
        ON DELETE SET NULL
        ON UPDATE CASCADE
);

-- Qualification
CREATE TABLE Qualification (
    QualID INT PRIMARY KEY,
    Emp_ID INT,
    Position VARCHAR(50),
    Requirements VARCHAR(255),
    Date_In DATE,
    CONSTRAINT fk_qualification_emp FOREIGN KEY (Emp_ID)
        REFERENCES Employee(emp_ID)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);

-- Leaves
CREATE TABLE Leaves (
    leave_ID INT PRIMARY KEY,
    emp_ID INT,
    date DATE,
    reason TEXT,
    CONSTRAINT fk_leave_emp FOREIGN KEY (emp_ID) REFERENCES Employee(emp_ID)
        ON DELETE CASCADE ON UPDATE CASCADE
);

-- Payroll
CREATE TABLE Payroll (
    payroll_ID INT PRIMARY KEY,
    emp_ID INT,
    job_ID INT,
    salary_ID INT,
    leave_ID INT,
    date DATE,
    report TEXT,
    total_amount DECIMAL(10,2),
    CONSTRAINT fk_payroll_emp FOREIGN KEY (emp_ID) REFERENCES Employee(emp_ID)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_payroll_job FOREIGN KEY (job_ID) REFERENCES JobDepartment(job_ID)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_payroll_salary FOREIGN KEY (salary_ID) REFERENCES SalaryBonus(salary_ID)
        ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT fk_payroll_leave FOREIGN KEY (leave_ID) REFERENCES Leaves(leave_ID)
        ON DELETE SET NULL ON UPDATE CASCADE
);

show tables;
select * from employee;
select * from SalaryBonus;
select * from JobDepartment;
select * from Qualification;
select * from Leaves;
select * from Payroll;

-- ANALYSIS QUESTIONS
-- EMPLOYEE INSIGHTS
-- 1. How many unique employees are currently in the system?
select count(distinct emp_id) as total_employees
from employee;

-- 2. Which departments have the highest number of employees?
select jobdept,count(e.emp_ID) as employee_count
from employee as e
join jobdepartment as j
on e.job_ID=j.job_ID
group by j.jobdept
order by employee_count desc;

-- 3.What is the average salary per department?
select j.jobdept,avg(s.amount) as avg_salary
from employee e
join jobdepartment as j
on e.job_id = j.job_id
join salarybonus as s
on j.job_id = s.job_id
group by j.jobdept;

-- 4.Who are the top 5 highest-paid employees?
select e.firstname,e.lastname,s.amount as salary
from employee e
join salarybonus as s
on e.job_id = s.job_id
order by s.amount desc
limit 5;

-- 5.What is the total salary expenditure across the company?
select sum(amount) as total_salary
from Salarybonus;

-- JOB ROLE AND DEPARTMENT ANALYSIS
-- 1.How many different job roles exist in each department?
select jobdept, count(name)
from Jobdepartment
group by jobdept;

-- 2.What is the average salary range per department?
select jobdept,avg(amount) as avg_salary
from jobdepartment j
join Salarybonus s
on j.job_id = s.job_id
group by jobdept;

-- 3.Which job roles offer the highest salary?
select name,amount as highest_salary
from Jobdepartment j
join Salarybonus s
on j.job_id = s.job_id
order by amount desc
limit 1;

-- 4.Which departments have the highest total salary allocation?
select jobdept,sum(amount)
from Jobdepartment j
join Salarybonus s
on j.job_id = s.job_id
group by jobdept
order by sum(amount) desc;

--  QUALIFICATION AND SKILLS ANALYSIS
-- 1.How many employees have at least one qualification listed?
select count(distinct emp_id)
from Qualification;

-- 2.Which positions require the most qualifications?
select position,count(requirements)
from Qualification
group by position
order by count(requirements) desc;

-- 3.Which employees have the highest number of qualifications?
select emp_id,count(*)
from Qualification
group by emp_id
order by count(*) desc
limit 1;

-- LEAVE AND ABSENCE PATTERNS
-- 1.Which year had the most employees taking leaves?
select year(date),count(distinct emp_id)
from leaves
group by year(date)
order by count(*) desc;

-- 2.What is the average number of leave days taken by its employees per department?
select jobdept,avg(leave_count) as avg_leaves
from (
       select emp_id,count(*) as leave_count
       from leaves
       group by emp_id
) l
join employee e
on e.emp_id = l.emp_id
join jobdepartment j
on e.job_id = j.job_id
group by jobdept;

-- 3.Which employees have taken the most leaves?
select emp_id,sum(extract(day from date)) as most_leaves
from leaves
group by emp_id
order by most_leaves desc;

-- 4.What is the total number of leave days taken company-wide?
select jobdept,sum(extract(day from date)) as total_leaves
from  leaves l
join employee e 
on e.emp_id = l.emp_id
join jobdepartment j
on e.job_id = j.job_id
group by jobdept
order by total_leaves desc;

-- 5.How do leave days correlate with payroll amounts?
select p.emp_id,p.date as pay_roll_date,total_amount,extract(day from l.date) as leave_day
from leaves l
join payroll p
on l.leave_id = p.leave_id;

-- PAYROLL AND COMPENSATION ANALYSIS
-- 1.What is the total monthly payroll processed?
select extract(year from date) as year,
extract(month from date) as month,
sum(total_amount) as total from payroll
group by extract(year from date),extract(month from date)
order by year,month;

-- 2.What is the average bonus given per department?
select jobdept,avg(bonus) as avg_bonus
from jobdepartment j
join Salarybonus s
on j.job_id = s.job_id
group by jobdept;

-- 3.Which department receives the highest total bonuses?
select jobdept,sum(bonus) as highest_bonus
from jobdepartment j
join Salarybonus s
on j.job_id = s.job_id
group by jobdept
order by highest_bonus desc;

-- 4.What is the average value of total_amount after considering leave deductions?
select avg(total_amount) as total_amount
from payroll;